/** Host entry for the installable Kimi-compatible PPT bundle. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Cordis plugin identity. */
export declare const name = "experimental-kimi-ppt";
/** Required host services. */
export declare const inject: string[];
/** Local storage and Kimi rendering ceilings. */
export interface Config {
    /** Absolute local root for state, revisions, and audit. */
    root: string;
    /** Maximum slides accepted in one generated presentation. */
    maxSlides?: number;
    /** Maximum persisted presentations in one DSH session. */
    maxDecksPerSession?: number;
    /** Maximum recent activity records retained in session state. */
    maxActivities?: number;
    /** Absolute Kimi-compatible PPT Skill override. The package-bundled Skill is the default. */
    kimiPptSkillRoot?: string;
}
/** Loader schema with conservative local defaults. */
export declare const Config: z<Config>;
/** Compose storage, browser RPC, and bounded model tools. */
export declare function apply(ctx: Context, config: Config): Promise<void>;
export type { KimiPptService } from './kimi-service.ts';
//# sourceMappingURL=index.d.ts.map