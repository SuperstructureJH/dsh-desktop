/** Model-facing tools for the Kimi-compatible PPTD workflow. */
import type { Context } from '@deepseek-ai/cordis';
import { type OfficePptState } from './protocol.ts';
import type { KimiPptService } from './kimi-service.ts';
/** Stable host guidance for the single PPTD route. */
export declare const KIMI_PPT_PROMPT: string;
/** Render authoritative composer state as model-only runtime context. */
export declare function kimiPptComposerContext(state: OfficePptState): string | undefined;
/** Register the Kimi-compatible presentation tools and session Skill injection. */
export declare function registerKimiPptTools(ctx: Context, service: KimiPptService): void;
//# sourceMappingURL=kimi-tools.d.ts.map