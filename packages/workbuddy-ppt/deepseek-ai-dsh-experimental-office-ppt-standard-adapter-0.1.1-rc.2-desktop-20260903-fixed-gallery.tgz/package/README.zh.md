# WorkBuddy PPT 标准 Composer 适配器

[English](README.md) | 中文

`@deepseek-ai/dsh-experimental-office-ppt-standard-adapter` 把共享的 [`dsh-workbuddy-ppt`](../office-ppt/README.zh.md) Host 与渲染器挂载到 DSH Harness 0.1.2 使用的标准 Composer 位置。同一套 PPT 实现可以同时服务现有 WorkBuddy Web 宿主和新版 DSH Desktop 宿主，无需复制生成、存储、 策略、审计或交付逻辑。

## 产品契约

适配器是装配包。Host 入口组合 `dsh-workbuddy-ppt`；浏览器入口把 Slides 操作注册到 agent preset 右侧的 `conversation.hero.modeActions`，把已选模板预览注册到输入框内部的 `conversation.input.accessory`，并把固定高度的模板目录注册到输入框下方的 `conversation.composer.dock`。目录独立滚动，打开 Slides 时输入框位置保持不变。三个位置只在空白会话显示，任务开始后恢复标准输入框。适配器自身不新增演示文稿工具、提示词、存储路径、渲染器或文件系统权限。

默认的 `dsh-workbuddy-ppt/client` 继续作为 WorkBuddy 客户端，保留 Harness 0.1.1-rc.2 提供的旧版 hero、 工具结果和 turn-tail 交付位置。适配器改为内联 `dsh-workbuddy-ppt/client-standard`；它的外部浏览器闭包只依赖 React、Harness 0.1.2-alpha.1 已有的标准 DSH Composer primitives、连接和多语言服务。

## 安装与组合

这个包是 DSH Desktop 的私有装配组件，不是市场条目。桌面应用内置适配器与版本一致的 `dsh-workbuddy-ppt` 产物，再为适配器插入一条 Loader 配置：

```yaml
- id: experimental-office-ppt-standard-adapter
  name: '@deepseek-ai/dsh-experimental-office-ppt-standard-adapter'
  root: =dshHomePath('office-ppt')
```

共享 root 让两个宿主上的 PPT 工程、不可变修订版和交付文件都进入同一个受限且由 Host 管理的位置。仅安装 核心包继续作为外部 WorkBuddy 路径；安装适配器则是 DSH Desktop 路径。

## 兼容边界

共享 Host 支持 Harness 0.1.1-rc.2 和 0.1.2-alpha.1。旧版 WorkBuddy 浏览器入口依赖 `@deepseek-ai/dsh-client-runtime` 和 WorkBuddy 专用插槽。标准适配器不会加载旧入口，因此共享包把该运行时 声明为可选 peer。标准适配器遵守 0.1.2 Composer 契约，不注册旧版 hero、tool-view 或 turn-tail 插槽。

普通浏览器文件选择在 Electron 和浏览器中都使用 Web `File` API。当前适配器只挂载 Slides 模式选择器；它不迁移独立的通用粘贴/上传插件，因为该插件依赖的浏览器服务在两版 Harness 之间已经变化。在该插件取得独立的标准运行时适配器之前，DSH 0.1.2 attachments 继续作为桌面宿主的文件入口。

## 验证

bundle 门禁只提供 React 和标准 Composer primitives 便加载编译后的客户端闭包。它核对闭包不包含旧版客户端运行时，注册模式、已选模板和模板目录三个位置，再完成卸载。真实 Loader 组合测试启动适配器 Host，并验证共享演示文稿 RPC 与工具表面可用。Host 与 client TypeScript 构建分别覆盖两个入口。

这些检查证明源码组合与已打包浏览器闭包。签名 DSH Desktop 构建实际启动插件、真实模型生成新演示文稿，以及 Microsoft PowerPoint 或 WPS 打开、编辑、保存并重新打开输出，仍是独立验收层。

## 模型体验

### 标准 Composer 适配器

#### 模型可见内容

适配器不新增模型可见内容。选择 Slides 后由共享核心注入包内 `tencent-pptx` 创作 Skill 到持久会话上下文，并暴露工程受限的 Slides 操作。

#### Token 影响

适配器不增加提示词或工具 schema。Token 使用跟随共享 Slides 路由：短路由契约和工具 schema 进入可复用前缀，创作 Skill 只在 Slides 会话中出现。

#### KV Cache 影响

标准 Composer 注册不改变模型输入。Cache 行为跟随共享核心；插件版本、路由与所选 Skill 内容不变时保持稳定。

## 已知限制与暂缓事项

- 标准适配器使用 0.1.2 通用工具结果和产出文件表面。WorkBuddy 专用 turn-tail PPT 预览与工具行继续由旧版 WorkBuddy 客户端提供。
- 通用全文件粘贴和上传需要独立的标准运行时适配器。Electron 本身可通过浏览器 `File` API 接收普通文件；待处理 工作是 Harness 客户端服务契约。
- 自动 bundle 与 Loader 检查不证明桌面安装包实际启动、模型行为、同事设备行为或 PowerPoint/WPS 打开编辑保存再打开闭环。
