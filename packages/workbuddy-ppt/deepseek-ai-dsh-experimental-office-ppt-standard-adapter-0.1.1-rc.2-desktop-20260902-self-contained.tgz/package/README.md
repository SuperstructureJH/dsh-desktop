# WorkBuddy PPT standard Composer adapter

English | [中文](README.zh.md)

`@deepseek-ai/dsh-experimental-office-ppt-standard-adapter` mounts the shared [`dsh-workbuddy-ppt`](../office-ppt/README.md) Host and renderer on the standard Composer seats used by DSH Harness 0.1.2. It lets one PPT implementation serve the existing WorkBuddy web host and the newer DSH Desktop host without copying the generation, storage, policy, audit, or delivery logic.

## Product contract

The adapter is an assembly package. Its Host entry composes `dsh-workbuddy-ppt`; its browser entry registers the selected-template preview on `conversation.input.left` and the shared chooser on `conversation.composer.dock` below the resident input card. The adapter adds no PPT tools, prompts, storage paths, renderer, or filesystem authority of its own.

The default `dsh-workbuddy-ppt/client` remains the WorkBuddy client. It keeps the legacy hero, tool-result, and turn-tail delivery seats supplied by Harness 0.1.1-rc.2. The adapter instead embeds `dsh-workbuddy-ppt/client-standard`, whose external browser closure requires only React, the standard DSH Composer primitives, connection, and locale services available in Harness 0.1.2-alpha.1.

## Installation and composition

This package is private assembly for DSH Desktop rather than a market listing. The desktop application vendors the adapter and the matching `dsh-workbuddy-ppt` artifact, then inserts one Loader row for the adapter:

```yaml
- id: experimental-office-ppt-standard-adapter
  name: '@deepseek-ai/dsh-experimental-office-ppt-standard-adapter'
  root: =dshHomePath('office-ppt')
```

The shared root keeps PPT projects, immutable revisions, and deliveries under the same confined Host-owned location on both hosts. Installing only the core package remains the external WorkBuddy path; installing the adapter is the DSH Desktop path.

## Compatibility boundary

The shared Host supports Harness 0.1.1-rc.2 and 0.1.2-alpha.1. The legacy WorkBuddy browser entry depends on `@deepseek-ai/dsh-client-runtime` and WorkBuddy-specific slots. That runtime is an optional peer of the shared package because the standard adapter does not load the legacy entry. The standard adapter supports the 0.1.2 Composer contract and does not register legacy hero, tool-view, or turn-tail slots.

Ordinary browser file selection uses the Web `File` API in Electron as well as in a browser. The current adapter mounts the PPT mode selector; it does not port the separate generic paste/upload plugin, whose browser services changed between the two Harness releases. DSH 0.1.2 attachments remain the active file intake for the desktop host until that plugin receives its own standard-runtime adapter.

## Verification

The bundle gate loads the built client closure with only React and standard Composer primitives. It verifies the absence of the legacy client runtime, registers the selected-template and below-composer seats, and disposes both. A real Loader composition test starts the adapter Host and verifies that the shared PPT RPC and tool surface are available. Host and client TypeScript builds cover both entries.

These checks prove source composition and the packaged browser closure. A signed DSH Desktop build launching the plugin, a real model generating a new deck, and Microsoft PowerPoint or WPS opening, editing, saving, and reopening the output remain separate acceptance layers.

## Model Experience

### Standard Composer adapter

#### What the model sees

The adapter adds no model-visible content. Selecting PPT activates the shared core, which injects the packaged `kimi-ppt` authoring Skill into durable session context and exposes the project-confined `pptd_*` operations.

#### Token effect

The adapter contributes no prompt or tool schema. Token use is the same as the selected shared PPT route: its short route contract and tool schemas enter the reusable prefix, while the authoring Skill appears only for PPT sessions.

#### KV Cache effect

The standard Composer registration does not alter model input. Cache behavior follows the shared core and remains stable while its plugin version, route, and selected Skill content stay unchanged.

## Known Limitations and Deferred Work

- The standard adapter uses the generic 0.1.2 tool-result and produced-file surfaces. The WorkBuddy-specific turn-tail PPT preview and dedicated tool rows remain on the legacy WorkBuddy client.
- Generic all-file paste and upload need a separate standard-runtime adapter. Electron itself accepts ordinary files through the browser `File` API; the outstanding work is the Harness client-service contract.
- Automated bundle and Loader checks do not prove a packaged desktop launch, model behavior, colleague-device behavior, or the PowerPoint/WPS edit-save-reopen round trip.
