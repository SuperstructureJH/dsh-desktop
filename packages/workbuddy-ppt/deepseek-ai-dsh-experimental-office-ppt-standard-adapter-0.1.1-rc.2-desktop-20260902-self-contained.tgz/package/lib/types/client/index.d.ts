/** Browser entry for the standard DSH Composer seats. */
import type { Context } from '@deepseek-ai/cordis';
/** Required standard browser services. */
export declare const inject: string[];
/** Mount the shared chooser on the standard Composer seats. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map